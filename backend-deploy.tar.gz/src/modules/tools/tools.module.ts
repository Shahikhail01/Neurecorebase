import { Module } from '@nestjs/common';
import { ToolsController } from './tools.controller';
import { ToolsService } from './tools.service';
import { HttpRequestTool } from './built-in/http-request.tool';
import { CalculatorTool } from './built-in/calculator.tool';

@Module({
  controllers: [ToolsController],
  providers: [HttpRequestTool, CalculatorTool, ToolsService],
  exports: [ToolsService],
})
export class ToolsModule {}
