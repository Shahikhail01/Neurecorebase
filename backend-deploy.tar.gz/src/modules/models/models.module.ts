import { Module } from '@nestjs/common';
import { ModelsController } from './models.controller';
import { ModelRoutingService } from './services/model-routing.service';

@Module({
  controllers: [ModelsController],
  providers: [ModelRoutingService],
  exports: [ModelRoutingService],
})
export class ModelsModule {}
