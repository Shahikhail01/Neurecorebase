import {
  Controller, Get, Post, Patch, Delete,
  Body, Param, Query, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { TasksService } from './services/tasks.service';
import { WorkflowsService } from './services/workflows.service';
import { CreateTaskDto, UpdateTaskDto } from './dto/task.dto';
import { CreateWorkflowDto, UpdateWorkflowDto } from './dto/workflow.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { JwtPayload } from '../auth/interfaces/token.interface';
import type { TaskStatus, WorkflowStatus } from '@prisma/client';

// ─────────────────────────────────────────────────────────────
// Tasks controller
// ─────────────────────────────────────────────────────────────

@Controller({ path: 'tasks', version: '1' })
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  @Get()
  findAll(
    @CurrentUser() user: JwtPayload,
    @Query('status') status?: TaskStatus,
    @Query('agentId') agentId?: string,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ) {
    return this.tasksService.findAll(user.tenantId!, { status, agentId, page: Number(page), limit: Number(limit) });
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.tasksService.findOne(id, user.tenantId!);
  }

  @Post()
  create(@Body() dto: CreateTaskDto, @CurrentUser() user: JwtPayload) {
    return this.tasksService.create({ ...dto, tenantId: user.tenantId!, createdById: user.sub });
  }

  @Patch(':id')
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateTaskDto, @CurrentUser() user: JwtPayload) {
    return this.tasksService.update(id, user.tenantId!, dto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.tasksService.remove(id, user.tenantId!);
  }
}

// ─────────────────────────────────────────────────────────────
// Workflows controller
// ─────────────────────────────────────────────────────────────

@Controller({ path: 'workflows', version: '1' })
export class WorkflowsController {
  constructor(private readonly workflowsService: WorkflowsService) {}

  @Get()
  findAll(
    @CurrentUser() user: JwtPayload,
    @Query('status') status?: WorkflowStatus,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ) {
    return this.workflowsService.findAll(user.tenantId!, { status, page: Number(page), limit: Number(limit) });
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.findOne(id, user.tenantId!);
  }

  @Post()
  create(@Body() dto: CreateWorkflowDto, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.create({ ...dto, tenantId: user.tenantId! });
  }

  @Patch(':id')
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateWorkflowDto, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.update(id, user.tenantId!, dto);
  }

  @Post(':id/activate')
  activate(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.activate(id, user.tenantId!);
  }

  /** POST /workflows/:id/execute — trigger workflow execution (fire & forget via WS events) */
  @Post(':id/execute')
  @HttpCode(HttpStatus.ACCEPTED)
  execute(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.execute(id, user.tenantId!);
  }

  /** GET /workflows/:id/status — current execution summary */
  @Get(':id/status')
  getStatus(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.getStatus(id, user.tenantId!);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowsService.remove(id, user.tenantId!);
  }
}
