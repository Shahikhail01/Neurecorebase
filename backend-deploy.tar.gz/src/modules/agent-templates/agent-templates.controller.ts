import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { AgentTemplatesService } from './agent-templates.service';
import {
  CreateAgentTemplateDto,
  UpdateAgentTemplateDto,
} from './dto/agent-template.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import type { JwtPayload } from '../auth/interfaces/token.interface';
import type { AgentType } from '@prisma/client';

/**
 * AgentTemplatesController  — /api/v1/agent-templates
 *
 * Exposes the template library to tenant users and admins.
 * All mutations are restricted to ADMIN/OWNER roles.
 */
@Controller({ path: 'agent-templates', version: '1' })
export class AgentTemplatesController {
  constructor(private readonly templatesService: AgentTemplatesService) {}

  // ─── List ─────────────────────────────────────────────────────────────────

  @Get()
  findAll(
    @CurrentUser() user: JwtPayload,
    @Query('type') type?: AgentType,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ) {
    return this.templatesService.findAll(user.tenantId!, {
      type,
      page: Number(page),
      limit: Number(limit),
    });
  }

  // ─── Read one ─────────────────────────────────────────────────────────────

  @Get(':id')
  findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.templatesService.findOne(id, user.tenantId!);
  }

  // ─── Instantiate template → agent create payload ──────────────────────────

  @Get(':id/instantiate')
  instantiate(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.templatesService.instantiate(id, user.tenantId!);
  }

  // ─── Create ───────────────────────────────────────────────────────────────

  @Post()
  @Roles('ADMIN', 'OWNER')
  create(@Body() dto: CreateAgentTemplateDto, @CurrentUser() user: JwtPayload) {
    return this.templatesService.create(user.tenantId!, dto);
  }

  // ─── Update ───────────────────────────────────────────────────────────────

  @Patch(':id')
  @Roles('ADMIN', 'OWNER')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateAgentTemplateDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.templatesService.update(id, user.tenantId!, dto);
  }

  // ─── Delete ───────────────────────────────────────────────────────────────

  @Delete(':id')
  @Roles('ADMIN', 'OWNER')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.templatesService.remove(id, user.tenantId!);
  }
}
