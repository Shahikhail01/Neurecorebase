import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/database/prisma.service';
import type { AgentType } from '@prisma/client';
import type {
  CreateAgentTemplateDto,
  UpdateAgentTemplateDto,
} from './dto/agent-template.dto';

/**
 * AgentTemplatesService
 *
 * SRP: Manages CRUD for AgentTemplate records only.
 * OCP: New template fields can be added by extending DTOs without modifying this service.
 * Tenant isolation: Templates are either tenant-specific (tenantId set) or
 * platform-public (isPublic = true, tenantId = null). Both are visible to a tenant.
 */
@Injectable()
export class AgentTemplatesService {
  private readonly logger = new Logger(AgentTemplatesService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(
    tenantId: string,
    opts?: { type?: AgentType; page?: number; limit?: number },
  ) {
    const { type, page = 1, limit = 20 } = opts ?? {};
    const skip = (page - 1) * limit;

    const where = {
      OR: [{ tenantId }, { isPublic: true }],
      ...(type && { type }),
    };

    const [data, total] = await this.prisma.$transaction([
      this.prisma.agentTemplate.findMany({
        where,
        skip,
        take: limit,
        orderBy: [{ isPublic: 'asc' }, { createdAt: 'desc' }],
      }),
      this.prisma.agentTemplate.count({ where }),
    ]);

    return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  async findOne(id: string, tenantId: string) {
    const template = await this.prisma.agentTemplate.findFirst({
      where: { id, OR: [{ tenantId }, { isPublic: true }] },
    });
    if (!template)
      throw new NotFoundException(`Agent template ${id} not found`);
    return template;
  }

  async create(tenantId: string, dto: CreateAgentTemplateDto) {
    return this.prisma.agentTemplate.create({
      data: {
        name: dto.name,
        description: dto.description,
        type: dto.type ?? 'FUNCTIONAL',
        model: dto.model ?? 'gpt-4o-mini',
        systemPrompt: dto.systemPrompt,
        instructions: dto.instructions,
        permissions: (dto.permissions ?? []) as never,
        config: (dto.config ?? {}) as never,
        isPublic: dto.isPublic ?? false,
        version: dto.version ?? '1.0.0',
        tenantId,
      },
    });
  }

  async update(id: string, tenantId: string, dto: UpdateAgentTemplateDto) {
    // Tenants can only update their own templates, not public ones
    const template = await this.prisma.agentTemplate.findFirst({
      where: { id, tenantId },
    });
    if (!template)
      throw new NotFoundException(
        `Agent template ${id} not found or not yours`,
      );

    return this.prisma.agentTemplate.update({
      where: { id },
      data: {
        ...(dto.name && { name: dto.name }),
        ...(dto.description !== undefined && { description: dto.description }),
        ...(dto.type && { type: dto.type }),
        ...(dto.model && { model: dto.model }),
        ...(dto.systemPrompt !== undefined && {
          systemPrompt: dto.systemPrompt,
        }),
        ...(dto.instructions !== undefined && {
          instructions: dto.instructions,
        }),
        ...(dto.permissions && { permissions: dto.permissions as never }),
        ...(dto.config && { config: dto.config as never }),
        ...(dto.isPublic !== undefined && { isPublic: dto.isPublic }),
        ...(dto.version && { version: dto.version }),
      },
    });
  }

  async remove(id: string, tenantId: string): Promise<void> {
    const template = await this.prisma.agentTemplate.findFirst({
      where: { id, tenantId },
    });
    if (!template)
      throw new NotFoundException(
        `Agent template ${id} not found or not yours`,
      );
    await this.prisma.agentTemplate.delete({ where: { id } });
  }

  /**
   * Instantiate a template — returns a create-agent payload pre-filled from the template.
   * The caller (AgentsService.create) takes this as input.
   */
  async instantiate(id: string, tenantId: string) {
    const template = await this.findOne(id, tenantId);
    return {
      name: template.name,
      description: template.description,
      type: template.type,
      model: template.model,
      systemPrompt: template.systemPrompt,
      instructions: template.instructions,
      permissions: template.permissions,
      config: template.config,
      templateId: template.id,
    };
  }
}
