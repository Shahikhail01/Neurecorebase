import {
  Controller, Get, Post, Patch, Delete,
  Body, Param, Query, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { GovernanceRulesService } from './services/governance-rules.service';
import { ApprovalsService } from './services/approvals.service';
import { CreateGovernanceRuleDto, UpdateGovernanceRuleDto } from './dto/governance.dto';
import { CreateApprovalDto, ReviewApprovalDto } from './dto/approval.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { JwtPayload } from '../auth/interfaces/token.interface';
import type { ApprovalStatus } from '@prisma/client';

// ─── Governance Rules ─────────────────────────────────────────────────────────

@Controller({ path: 'governance/rules', version: '1' })
export class GovernanceRulesController {
  constructor(private readonly rulesService: GovernanceRulesService) {}

  @Get()
  findAll(@CurrentUser() user: JwtPayload) {
    return this.rulesService.findAll(user.tenantId!);
  }

  @Post()
  create(@Body() dto: CreateGovernanceRuleDto, @CurrentUser() user: JwtPayload) {
    return this.rulesService.create(user.tenantId!, dto);
  }

  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateGovernanceRuleDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.rulesService.update(id, user.tenantId!, dto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.rulesService.remove(id, user.tenantId!);
  }

  @Post('evaluate')
  evaluate(@Body() context: Record<string, unknown>, @CurrentUser() user: JwtPayload) {
    return this.rulesService.evaluate(user.tenantId!, context);
  }

  /**
   * POST /governance/rules/validate — validate a proposed action context against active rules.
   * Spec-defined alias for evaluate.
   */
  @Post('validate')
  validate(@Body() context: Record<string, unknown>, @CurrentUser() user: JwtPayload) {
    return this.rulesService.evaluate(user.tenantId!, context);
  }

  /**
   * GET /governance/rules/audit/:agentId — governance decision history for a specific agent.
   */
  @Get('audit/:agentId')
  getAgentAudit(
    @Param('agentId', ParseUUIDPipe) agentId: string,
    @CurrentUser() user: JwtPayload,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ) {
    return this.rulesService.getAgentAudit(agentId, user.tenantId!, {
      page: Number(page),
      limit: Number(limit),
    });
  }
}

// ─── Approvals ────────────────────────────────────────────────────────────────

@Controller({ path: 'approvals', version: '1' })
export class ApprovalsController {
  constructor(private readonly approvalsService: ApprovalsService) {}

  @Get()
  findAll(
    @CurrentUser() user: JwtPayload,
    @Query('status') status?: ApprovalStatus,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ) {
    return this.approvalsService.findAll(user.tenantId!, {
      status,
      page: Number(page),
      limit: Number(limit),
    });
  }

  @Get('pending-count')
  pendingCount(@CurrentUser() user: JwtPayload) {
    return this.approvalsService.getPendingCount(user.tenantId!);
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.approvalsService.findOne(id, user.tenantId!);
  }

  /** GET /approvals/:id/history — full lifecycle timeline of an approval request */
  @Get(':id/history')
  getHistory(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.approvalsService.getHistory(id, user.tenantId!);
  }

  @Post()
  create(@Body() dto: CreateApprovalDto, @CurrentUser() user: JwtPayload) {
    return this.approvalsService.create({ ...dto, tenantId: user.tenantId!, requestedById: user.sub });
  }

  @Patch(':id/review')
  review(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: ReviewApprovalDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.approvalsService.review(id, user.tenantId!, user.sub, dto);
  }

  @Patch(':id/cancel')
  @HttpCode(HttpStatus.OK)
  cancel(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.approvalsService.cancel(id, user.tenantId!, user.sub);
  }
}
