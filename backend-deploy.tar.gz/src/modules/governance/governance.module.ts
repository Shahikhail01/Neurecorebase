import { Module } from '@nestjs/common';
import { GovernanceRulesController, ApprovalsController } from './governance.controller';
import { GovernanceRulesService } from './services/governance-rules.service';
import { ApprovalsService } from './services/approvals.service';

@Module({
  controllers: [GovernanceRulesController, ApprovalsController],
  providers: [GovernanceRulesService, ApprovalsService],
  exports: [GovernanceRulesService, ApprovalsService],
})
export class GovernanceModule {}
