import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { AgentsService } from './services/agents.service';
import { AgentExecutorService } from './services/agent-executor.service';
import { CreateAgentDto } from './dto/create-agent.dto';
import { UpdateAgentDto } from './dto/update-agent.dto';
import { DispatchTaskDto } from './dto/dispatch-task.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import type { JwtPayload } from '../auth/interfaces/token.interface';
import { AgentStatus, AgentType } from '@prisma/client';
import { IsArray, IsOptional, IsString } from 'class-validator';

class UpdatePermissionsDto {
  @IsArray()
  @IsString({ each: true })
  permissions!: string[];

  @IsOptional()
  @IsString()
  budgetPerDay?: string;
}

@Controller({ path: 'agents', version: '1' })
export class AgentsController {
  constructor(
    private readonly agentsService: AgentsService,
    private readonly executorService: AgentExecutorService,
  ) {}

  // ─── List ────────────────────────────────────────────────

  @Get()
  findAll(
    @CurrentUser() user: JwtPayload,
    @Query('status') status?: AgentStatus,
    @Query('type') type?: AgentType,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ) {
    return this.agentsService.findAll({
      tenantId: user.tenantId!,
      status,
      type,
      page: Number(page),
      limit: Number(limit),
    });
  }

  // ─── Read one ────────────────────────────────────────────

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.agentsService.findOne(id, user.tenantId!);
  }

  // ─── Status ──────────────────────────────────────────────

  @Get(':id/status')
  getStatus(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.agentsService.findOne(id, user.tenantId!);
  }

  // ─── Create ──────────────────────────────────────────────

  @Post()
  @Roles('ADMIN', 'OWNER')
  create(@Body() dto: CreateAgentDto, @CurrentUser() user: JwtPayload) {
    return this.agentsService.create(dto, user.tenantId!, user.sub);
  }

  // ─── Update ──────────────────────────────────────────────

  @Patch(':id')
  @Roles('ADMIN', 'OWNER')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateAgentDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.agentsService.update(id, dto, user.tenantId!);
  }

  // ─── Permissions ─────────────────────────────────────────

  /** PATCH /agents/:id/permissions — update allowed actions & budget */
  @Patch(':id/permissions')
  @Roles('ADMIN', 'OWNER')
  updatePermissions(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdatePermissionsDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.agentsService.update(
      id,
      { permissions: dto.permissions, budgetPerDay: dto.budgetPerDay } as UpdateAgentDto,
      user.tenantId!,
    );
  }

  // ─── Pause ───────────────────────────────────────────────

  @Post(':id/pause')
  @HttpCode(HttpStatus.OK)
  async pause(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    const agent = await this.agentsService.updateStatus(id, AgentStatus.PAUSED, user.tenantId!);
    return { message: 'Agent paused', agent };
  }

  // ─── Resume ──────────────────────────────────────────────

  @Post(':id/resume')
  @HttpCode(HttpStatus.OK)
  async resume(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    const agent = await this.agentsService.updateStatus(id, AgentStatus.IDLE, user.tenantId!);
    return { message: 'Agent resumed', agent };
  }

  // ─── Delete ──────────────────────────────────────────────

  @Delete(':id')
  @Roles('ADMIN', 'OWNER')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser() user: JwtPayload) {
    return this.agentsService.remove(id, user.tenantId!);
  }

  // ─── Dispatch task to agent ──────────────────────────────

  @Post(':id/dispatch')
  @HttpCode(HttpStatus.ACCEPTED)
  async dispatch(
    @Param('id', ParseUUIDPipe) agentId: string,
    @Body() dto: DispatchTaskDto,
    @CurrentUser() user: JwtPayload,
  ) {
    // Fire-and-forget; client tracks progress via WebSocket
    void this.executorService.executeTask(dto.taskId, agentId, user.tenantId!);
    return { message: 'Task dispatched', taskId: dto.taskId, agentId };
  }

  /** POST /agents/:id/task — spec alias for /dispatch */
  @Post(':id/task')
  @HttpCode(HttpStatus.ACCEPTED)
  async dispatchTask(
    @Param('id', ParseUUIDPipe) agentId: string,
    @Body() dto: DispatchTaskDto,
    @CurrentUser() user: JwtPayload,
  ) {
    void this.executorService.executeTask(dto.taskId, agentId, user.tenantId!);
    return { message: 'Task dispatched', taskId: dto.taskId, agentId };
  }

  // ─── Cancel task ─────────────────────────────────────────

  @Post(':id/cancel/:taskId')
  @HttpCode(HttpStatus.OK)
  cancel(
    @Param('taskId', ParseUUIDPipe) taskId: string,
  ) {
    return this.executorService.cancelTask(taskId);
  }
}
