import { Injectable, Logger, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/database/prisma.service';
import { EventsGateway } from '../../events/events.gateway';
import { AgentEvaluatorService } from './agent-evaluator.service';
import { ToolsService } from '../../tools/tools.service';
import { GovernanceRulesService } from '../../governance/services/governance-rules.service';
import type {
  IAgentExecutor,
  ExecutionContext,
  StepResult,
  ExecutionResult,
} from '../interfaces/agent-executor.interface';
import { TaskStatus, AgentStatus } from '@prisma/client';

/**
 * AgentExecutorService
 *
 * Responsibility (SRP): Execute a single plan step or an entire task by
 * running steps in dependency order, persisting execution logs, emitting
 * real-time WebSocket events, and delegating evaluation to AgentEvaluatorService.
 *
 * SOLID:
 *  - SRP: executes only — delegates planning to planner, scoring to evaluator
 *  - DIP: depends on IAgentExecutor, ToolsService, EventsGateway abstractions
 *  - OCP: tool dispatch is open for extension via ToolsService registry
 */
@Injectable()
export class AgentExecutorService implements IAgentExecutor {
  private readonly logger = new Logger(AgentExecutorService.name);
  private readonly runningTasks = new Map<string, boolean>(); // taskId → cancelled

  constructor(
    private readonly prisma: PrismaService,
    private readonly events: EventsGateway,
    private readonly evaluator: AgentEvaluatorService,
    private readonly tools: ToolsService,
    private readonly governance: GovernanceRulesService,
  ) {}

  async execute(context: ExecutionContext): Promise<StepResult> {
    const start = Date.now();
    this.logger.debug(`Executing step ${context.step.id} for task ${context.taskId}`);

    try {
      let output: unknown;

      // If step specifies a toolId, invoke it via ToolsService (DIP / OCP)
      if (context.step.toolId) {
        const toolResult = await this.tools.execute(
          context.step.toolId,
          (context.step.input ?? {}) as Record<string, unknown>,
        );
        output = toolResult.success ? toolResult.data : { error: toolResult.error };
        if (!toolResult.success) throw new Error(toolResult.error ?? 'Tool execution failed');
      } else {
        output = { result: `Step "${context.step.description}" completed` };
      }

      const durationMs = Date.now() - start;
      await this.persistLog(context, output, durationMs, true);

      return { stepId: context.step.id, success: true, output, durationMs };
    } catch (err: unknown) {
      const error = err instanceof Error ? err.message : String(err);
      const durationMs = Date.now() - start;
      await this.persistLog(context, null, durationMs, false, error);
      return { stepId: context.step.id, success: false, error, durationMs };
    }
  }

  async executeTask(
    taskId: string,
    agentId: string,
    tenantId: string,
  ): Promise<ExecutionResult> {
    const start = Date.now();
    this.runningTasks.set(taskId, false);

    // ─── Governance pre-check ───
    try {
      const task = await this.prisma.task.findUnique({
        where: { id: taskId },
        select: { title: true, priority: true },
      });
      const decision = await this.governance.evaluate(tenantId, {
        'task.id': taskId,
        'task.title': task?.title ?? '',
        'agent.id': agentId,
      });

      if (!decision.allowed) {
        // Update task to FAILED with reason
        await this.prisma.task.update({
          where: { id: taskId },
          data: { status: TaskStatus.FAILED, error: `Blocked by governance: ${decision.triggeredRules.join(', ')}` },
        });
        this.events.emitAgentError(tenantId, agentId, taskId, `Governance blocked: ${decision.triggeredRules.join(', ')}`);
        this.events.emitGovernanceTriggered(tenantId, agentId, decision);
        throw new ForbiddenException(`Task blocked by governance rules: ${decision.triggeredRules.join(', ')}`);
      }

      if (decision.requiresApproval) {
        // Surface the decision via WebSocket; don't block (approval created separately by calling code)
        this.events.emitGovernanceTriggered(tenantId, agentId, decision);
        this.logger.warn(`[Governance] Task ${taskId} requires approval — triggered rules: ${decision.triggeredRules.join(', ')}`);
      }
    } catch (govErr) {
      if (govErr instanceof ForbiddenException) throw govErr;
      // Governance failures are non-fatal to avoid blocking execution on infrastructure issues
      this.logger.warn(`[Governance] Pre-check failed for task ${taskId}: ${String(govErr)}`);
    }
    // ─── End governance pre-check ───

    await this.prisma.task.update({
      where: { id: taskId },
      data: { status: TaskStatus.RUNNING, startedAt: new Date() },
    });

    await this.prisma.agent.update({
      where: { id: agentId },
      data: { status: AgentStatus.RUNNING },
    });

    this.events.emitToTenant(tenantId, 'task:started', { taskId, agentId });

    const results: StepResult[] = [];
    let totalTokens = 0;
    let totalCost = 0;
    let finalOutput: unknown;
    let overallError: string | undefined;

    try {
      // Retrieve task and plan steps (stored in task.input.steps for now)
      const task = await this.prisma.task.findUniqueOrThrow({ where: { id: taskId } });
      const steps: Array<{ id: string; description: string; toolId?: string; input?: Record<string, unknown>; dependsOn?: string[] }> =
        (task.input as Record<string, unknown>)?.steps as never[] ?? [
          { id: 'default', description: 'Execute task', input: task.input as Record<string, unknown> },
        ];

      const completedIds = new Set<string>();
      const stepMap = new Map(steps.map((s) => [s.id, s]));

      // Topological execution respecting dependsOn
      while (completedIds.size < steps.length) {
        const cancelled = this.runningTasks.get(taskId);
        if (cancelled) {
          overallError = 'Task cancelled';
          break;
        }

        // Find next step whose dependencies are all satisfied
        const next = steps.find(
          (s) =>
            !completedIds.has(s.id) &&
            (s.dependsOn ?? []).every((d) => completedIds.has(d)),
        );
        if (!next) break; // circular or all done

        const ctx: ExecutionContext = {
          taskId,
          agentId,
          tenantId,
          step: next,
          availableTools: [],
          previousResults: new Map(results.map((r) => [r.stepId, r])),
        };

        const result = await this.execute(ctx);
        results.push(result);
        completedIds.add(next.id);

        totalTokens += result.tokensUsed ?? 0;
        totalCost += result.costUsd ?? 0;
        finalOutput = result.output;

        if (!result.success) {
          overallError = result.error;
          break;
        }
      }
    } catch (err: unknown) {
      overallError = err instanceof Error ? err.message : String(err);
    }

    const totalDurationMs = Date.now() - start;
    const success = !overallError;

    // Emit agent:error before updating task status so subscribers receive it promptly
    if (!success) {
      this.events.emitAgentError(tenantId, agentId, taskId, overallError ?? 'Unknown error');
    }

    await this.prisma.task.update({
      where: { id: taskId },
      data: {
        status: success ? TaskStatus.COMPLETED : TaskStatus.FAILED,
        completedAt: new Date(),
        output: finalOutput as never ?? null,
        error: overallError ?? null,
      },
    });

    await this.prisma.agent.update({
      where: { id: agentId },
      data: { status: AgentStatus.IDLE },
    });

    // ── Evaluate execution quality ──────────────────────────
    try {
      const task = await this.prisma.task.findUnique({ where: { id: taskId } });
      const evaluation = await this.evaluator.evaluate({
        agentId,
        taskId,
        goal: task?.title ?? 'unknown',
        steps: results.map((r) => ({
          id: r.stepId,
          description: r.stepId,
          output: r.output,
          success: r.success,
        })),
        finalOutput,
      });

      this.events.emitToTenant(tenantId, 'agent:evaluated', {
        taskId,
        agentId,
        score: evaluation.score,
        reflection: evaluation.reflection,
        shouldRetry: evaluation.shouldRetry,
      });

      this.logger.log(
        `Task ${taskId} evaluation: score=${evaluation.score} shouldRetry=${evaluation.shouldRetry}`,
      );
    } catch (evalErr) {
      this.logger.warn(`Evaluation failed for task ${taskId}: ${String(evalErr)}`);
    }

    const event = success ? 'task:completed' : 'task:failed';
    this.events.emitToTenant(tenantId, event, { taskId, agentId, success, error: overallError });

    this.runningTasks.delete(taskId);

    return {
      taskId,
      agentId,
      success,
      steps: results,
      finalOutput,
      error: overallError,
      totalDurationMs,
      totalTokensUsed: totalTokens,
      totalCostUsd: totalCost,
    };
  }

  async cancelTask(taskId: string): Promise<void> {
    if (this.runningTasks.has(taskId)) {
      this.runningTasks.set(taskId, true);
    }
    await this.prisma.task.update({
      where: { id: taskId },
      data: { status: TaskStatus.CANCELLED },
    });
  }

  // ───────────────────────────────────────────────────────────
  // Private helpers
  // ───────────────────────────────────────────────────────────

  private async persistLog(
    ctx: ExecutionContext,
    output: unknown,
    durationMs: number,
    success: boolean,
    error?: string,
  ): Promise<void> {
    await this.prisma.executionLog.create({
      data: {
        agentId: ctx.agentId,
        taskId: ctx.taskId,
        step: ctx.step.id,
        input: (ctx.step.input ?? {}) as never,
        output: output as never ?? undefined,
        durationMs,
        success,
        error: error ?? null,
      },
    });
  }
}
