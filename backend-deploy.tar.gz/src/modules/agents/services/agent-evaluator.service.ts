import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type {
  IAgentEvaluator,
  EvaluationInput,
  EvaluationResult,
} from '../interfaces/agent-evaluator.interface';

/**
 * AgentEvaluatorService
 *
 * Responsibility (SRP): Score the quality of a completed task execution
 * and produce reflective feedback.  Implements the reflection loop pattern
 * — results feed back into the planner for future tasks.
 *
 * LangChain is used when OPENAI_API_KEY is available; falls back to
 * heuristic scoring so the platform remains functional without an API key.
 *
 * SOLID:
 *  - SRP: only evaluates — does not plan or execute
 *  - OCP: scoring strategy swappable via subclass (LLM vs heuristic)
 *  - DIP: depends on IAgentEvaluator abstraction + ConfigService injection
 */
@Injectable()
export class AgentEvaluatorService implements IAgentEvaluator {
  private readonly logger = new Logger(AgentEvaluatorService.name);

  constructor(private readonly config: ConfigService) {}

  async evaluate(input: EvaluationInput): Promise<EvaluationResult> {
    this.logger.debug(
      `Evaluating task ${input.taskId} for agent ${input.agentId}`,
    );

    const apiKey = this.config.get<string>('OPENAI_API_KEY');

    if (apiKey) {
      return this.llmEvaluate(input, apiKey);
    }

    return this.heuristicEvaluate(input);
  }

  // ───────────────────────────────────────────────────────────
  // LangChain-based evaluation
  // ───────────────────────────────────────────────────────────

  private async llmEvaluate(
    input: EvaluationInput,
    apiKey: string,
  ): Promise<EvaluationResult> {
    try {
      // Dynamic import keeps startup fast when LangChain is not needed
      const { ChatOpenAI } = await import('@langchain/openai');
      const { ChatPromptTemplate } = await import('@langchain/core/prompts');
      const { StringOutputParser } = await import('@langchain/core/output_parsers');

      const llm = new ChatOpenAI({
        apiKey,
        model: 'gpt-4o-mini',
        temperature: 0,
        maxTokens: 512,
      });

      const stepSummary = input.steps
        .map(
          (s) =>
            `- ${s.description}: ${s.success ? '✓' : '✗'} ${
              s.output ? JSON.stringify(s.output).slice(0, 100) : ''
            }`,
        )
        .join('\n');

      const prompt = ChatPromptTemplate.fromMessages([
        [
          'system',
          `You are an AI task evaluator. Evaluate the quality of an AI agent's task execution.
Respond ONLY with valid JSON in this exact format:
{
  "score": <0.0-1.0>,
  "success": <true|false>,
  "reflection": "<one sentence summary>",
  "suggestions": ["<improvement 1>", "<improvement 2>"],
  "shouldRetry": <true|false>
}`,
        ],
        [
          'human',
          `Goal: {goal}\n\nSteps executed:\n{steps}\n\nFinal output: {output}`,
        ],
      ]);

      const chain = prompt.pipe(llm).pipe(new StringOutputParser());

      const raw = await chain.invoke({
        goal: input.goal,
        steps: stepSummary,
        output: JSON.stringify(input.finalOutput ?? null).slice(0, 200),
      });

      const parsed = JSON.parse(raw) as EvaluationResult;
      this.logger.debug(
        `LLM evaluation score for task ${input.taskId}: ${parsed.score}`,
      );
      return parsed;
    } catch (err) {
      this.logger.warn(
        `LLM evaluation failed, falling back to heuristic: ${String(err)}`,
      );
      return this.heuristicEvaluate(input);
    }
  }

  // ───────────────────────────────────────────────────────────
  // Heuristic fallback (no LLM required)
  // ───────────────────────────────────────────────────────────

  private heuristicEvaluate(input: EvaluationInput): EvaluationResult {
    const total = input.steps.length;
    const passed = input.steps.filter((s) => s.success).length;
    const score = total === 0 ? 0 : passed / total;
    const success = score >= 0.8;

    return {
      score,
      success,
      reflection:
        success
          ? `Task completed successfully: ${passed}/${total} steps passed.`
          : `Task partially failed: ${passed}/${total} steps passed.`,
      suggestions:
        success
          ? []
          : [
              'Review failed steps and provide more context in the next attempt.',
              'Consider breaking the goal into smaller sub-tasks.',
            ],
      shouldRetry: !success && score > 0,
    };
  }
}
