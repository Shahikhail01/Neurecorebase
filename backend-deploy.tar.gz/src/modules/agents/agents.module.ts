import { Module, forwardRef } from '@nestjs/common';
import { AgentsController } from './agents.controller';
import { AgentsService } from './services/agents.service';
import { AgentPlannerService } from './services/agent-planner.service';
import { AgentExecutorService } from './services/agent-executor.service';
import { AgentEvaluatorService } from './services/agent-evaluator.service';
import { EventsModule } from '../events/events.module';
import { ToolsModule } from '../tools/tools.module';
import { GovernanceModule } from '../governance/governance.module';

/**
 * AgentsModule
 *
 * SOLID — OCP: new agent types/services added without modifying this module.
 * DIP: all providers injected via module system, not constructed directly.
 */
@Module({
  imports: [forwardRef(() => EventsModule), ToolsModule, GovernanceModule],
  controllers: [AgentsController],
  providers: [
    AgentsService,
    AgentPlannerService,
    AgentExecutorService,
    AgentEvaluatorService,
  ],
  exports: [AgentsService, AgentPlannerService, AgentExecutorService, AgentEvaluatorService],
})
export class AgentsModule {}
