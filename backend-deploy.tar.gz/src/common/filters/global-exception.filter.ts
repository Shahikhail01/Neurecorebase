import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ApiResponse, ErrorCode } from '../types/api-response.types';
import { v4 as uuidv4 } from 'uuid';

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const requestId = uuidv4();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let code = ErrorCode.INTERNAL_ERROR;
    let message = 'An unexpected error occurred';
    let details: Record<string, unknown> | undefined;

    if (exception instanceof HttpException) {
      const httpEx = exception as HttpException;
      status = httpEx.getStatus();
      const exceptionResponse = httpEx.getResponse();

      if (typeof exceptionResponse === 'object' && exceptionResponse !== null) {
        const res = exceptionResponse as Record<string, unknown>;
        message = (res['message'] as string) ?? httpEx.message;

        // Handle class-validator errors (array of messages)
        if (Array.isArray(res['message'])) {
          message = 'Validation failed';
          details = { errors: res['message'] };
        }
      } else if (typeof exceptionResponse === 'string') {
        message = exceptionResponse;
      }

      code = this.statusToCode(status) as typeof code;
    } else if (exception instanceof Error) {
      const err = exception as Error;
      this.logger.error(`Unhandled error: ${err.message}`, err.stack);
    } else {
      this.logger.error('Unknown exception', String(exception));
    }

    const body: ApiResponse = {
      status: 'error',
      error: { code, message, details },
      meta: { timestamp: new Date().toISOString(), requestId },
    };

    response.status(status).json(body);
  }

  private statusToCode(status: number): typeof ErrorCode[keyof typeof ErrorCode] {
    const map: Record<number, typeof ErrorCode[keyof typeof ErrorCode]> = {
      400: ErrorCode.INVALID_REQUEST,
      401: ErrorCode.AUTHENTICATION_FAILED,
      403: ErrorCode.PERMISSION_DENIED,
      404: ErrorCode.NOT_FOUND,
      409: ErrorCode.CONFLICT,
      429: ErrorCode.RATE_LIMIT_EXCEEDED,
      503: ErrorCode.SERVICE_UNAVAILABLE,
    };
    return map[status] ?? ErrorCode.INTERNAL_ERROR;
  }
}
