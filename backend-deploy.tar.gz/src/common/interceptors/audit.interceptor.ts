import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable, tap, catchError, throwError } from 'rxjs';
import type { Request } from 'express';
import { AuditService } from '../../modules/audit/audit.service';

/**
 * AuditInterceptor — SRP: intercepts mutating requests (POST/PUT/PATCH/DELETE)
 * and writes an AuditLog entry after the handler completes.
 * OCP: extendable by adding conditions; does not modify other interceptors.
 */
@Injectable()
export class AuditInterceptor implements NestInterceptor {
  private readonly logger = new Logger(AuditInterceptor.name);

  // Paths to skip audit logging (health, static)
  private static readonly SKIP_PATHS = [
    '/api/v1/health',
    '/api/v1/auth/refresh',
  ];

  constructor(private readonly auditService: AuditService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req = context.switchToHttp().getRequest<
      Request & {
        user?: { sub?: string; tenantId?: string | null };
      }
    >();

    const method = req.method;

    // Only audit mutating operations
    if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      return next.handle();
    }

    // Skip certain paths
    if (AuditInterceptor.SKIP_PATHS.some((p) => req.path.startsWith(p))) {
      return next.handle();
    }

    const actor = req.user?.sub ?? 'anonymous';
    const tenantId = req.user?.tenantId ?? undefined;
    const ipAddress = req.ip;
    const userAgent = req.headers['user-agent'];

    // Derive resource/resourceId from route path
    const segments = req.path
      .replace(/\/api\/v\d+\//, '')
      .split('/')
      .filter(Boolean);
    const resource = segments[0] ?? 'unknown';
    // UUID-shaped segment after resource name
    const uuidPattern =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const resourceId =
      segments[1] && uuidPattern.test(segments[1]) ? segments[1] : undefined;

    const action = `${resource}.${method.toLowerCase()}`;

    return next.handle().pipe(
      tap(() => {
        void this.auditService.log({
          actor,
          action,
          resource,
          resourceId,
          tenantId,
          ipAddress,
          userAgent,
          result: 'success',
          details: { path: req.path, method },
        });
      }),
      catchError((err: unknown) => {
        void this.auditService.log({
          actor,
          action,
          resource,
          resourceId,
          tenantId,
          ipAddress,
          userAgent,
          result: 'failure',
          details: { path: req.path, method, error: String(err) },
        });
        return throwError(() => err);
      }),
    );
  }
}
