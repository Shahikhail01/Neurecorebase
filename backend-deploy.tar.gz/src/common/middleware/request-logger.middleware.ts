import { Injectable, NestMiddleware, Logger } from '@nestjs/common';
import type { Request, Response, NextFunction } from 'express';

/**
 * RequestLoggerMiddleware — SRP: logs every HTTP request with method/path/status/ms.
 * Plugged into AppModule globally via configure(consumer).
 * OCP: format is a single private helper; easy to extend to pino/winston output.
 */
@Injectable()
export class RequestLoggerMiddleware implements NestMiddleware {
  private readonly logger = new Logger('HTTP');

  use(req: Request, res: Response, next: NextFunction): void {
    const { method, originalUrl, ip } = req;
    const start = Date.now();

    res.on('finish', () => {
      const ms = Date.now() - start;
      const { statusCode } = res;
      const level = statusCode >= 500 ? 'error' : statusCode >= 400 ? 'warn' : 'log';
      this.logger[level](
        `${method} ${originalUrl} ${statusCode} ${ms}ms — ${ip ?? '?'}`,
      );
    });

    next();
  }
}
