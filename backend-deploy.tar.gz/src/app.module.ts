import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD, APP_FILTER, APP_INTERCEPTOR } from '@nestjs/core';

import { validate } from './config/env.validation';
import { DatabaseModule } from './infrastructure/database/database.module';
import { CacheModule } from './infrastructure/cache/cache.module';
import { AuthModule } from './modules/auth/auth.module';
import { TenantsModule } from './modules/tenants/tenants.module';
import { UsersModule } from './modules/users/users.module';
import { HealthModule } from './modules/health/health.module';
import { EventsModule } from './modules/events/events.module';
import { AgentsModule } from './modules/agents/agents.module';
import { MemoryModule } from './modules/memory/memory.module';
import { ToolsModule } from './modules/tools/tools.module';
import { OrchestrationModule } from './modules/orchestration/orchestration.module';
// Phase 3
import { GovernanceModule } from './modules/governance/governance.module';
import { ObservabilityModule } from './modules/observability/observability.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { DepartmentsModule } from './modules/departments/departments.module';
import { ModelsModule } from './modules/models/models.module';
import { AuditModule } from './modules/audit/audit.module';
import { AgentTemplatesModule } from './modules/agent-templates/agent-templates.module';
import { GlobalExceptionFilter } from './common/filters/global-exception.filter';
import { TransformResponseInterceptor } from './common/interceptors/transform-response.interceptor';
import { AuditInterceptor } from './common/interceptors/audit.interceptor';
import { RequestLoggerMiddleware } from './common/middleware/request-logger.middleware';
import { JwtAuthGuard } from './modules/auth/guards/jwt-auth.guard';
import { RolesGuard } from './modules/auth/guards/roles.guard';

@Module({
  imports: [
    // Config — global, validates env vars at boot
    ConfigModule.forRoot({ isGlobal: true, validate }),

    // Rate limiting: 100 req / 60 s per IP
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]),

    // Infrastructure (global — no need to import elsewhere)
    DatabaseModule,
    CacheModule,

    // Feature modules
    AuthModule,
    TenantsModule,
    UsersModule,
    HealthModule,
    EventsModule,

    // Phase 2 — Agent Runtime
    AgentsModule,
    MemoryModule,
    ToolsModule,
    OrchestrationModule,

    // Phase 3 — Governance, Observability, Notifications, Departments, Models
    GovernanceModule,
    ObservabilityModule,
    NotificationsModule,
    DepartmentsModule,
    ModelsModule,

    // Cross-cutting
    AuditModule,          // @Global — AuditService available everywhere
    AgentTemplatesModule, // Phase 2 — template library
  ],
  providers: [
    // Global rate-limit guard
    { provide: APP_GUARD, useClass: ThrottlerGuard },

    // Global JWT guard (routes opt-out with @Public())
    { provide: APP_GUARD, useClass: JwtAuthGuard },

    // Global role guard
    { provide: APP_GUARD, useClass: RolesGuard },

    // Global exception → ApiResponse envelope
    { provide: APP_FILTER, useClass: GlobalExceptionFilter },

    // Global success → ApiResponse envelope
    { provide: APP_INTERCEPTOR, useClass: TransformResponseInterceptor },

    // Global audit interceptor — writes audit logs for every mutating request
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(RequestLoggerMiddleware).forRoutes('*');
  }
}

