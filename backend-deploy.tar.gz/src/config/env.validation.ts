import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(3000),

  TENANT_FRONTEND_URL: z.string().url().default('http://localhost:3001'),
  ADMIN_FRONTEND_URL: z.string().url().default('http://localhost:3002'),

  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1).default('redis://localhost:6379/0'),

  JWT_SECRET: z.string().min(32),
  JWT_ACCESS_EXPIRES: z.string().default('15m'),
  JWT_REFRESH_EXPIRES: z.string().default('7d'),

  OPENAI_API_KEY: z.string().optional(),
  ANTHROPIC_API_KEY: z.string().optional(),

  THROTTLE_TTL: z.coerce.number().default(60000),
  THROTTLE_LIMIT: z.coerce.number().default(60),
});

export type AppConfig = z.infer<typeof envSchema>;

export const validate = (config: Record<string, unknown>): AppConfig => {
  const result = envSchema.safeParse(config);
  if (!result.success) {
    const formatted = result.error.format();
    throw new Error(`Config validation error: ${JSON.stringify(formatted, null, 2)}`);
  }
  return result.data;
};
